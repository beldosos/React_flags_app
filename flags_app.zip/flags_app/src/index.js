import React from 'react';
import axios from 'axios';
import ReactDOM from 'react-dom';
import './index.css';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      list: []
    };
  }

  render() {
    return (
        <div className="content">
            <div className="container">
            <div className="center">
            <h2>Flag Picker</h2>
            <h3>This app will help you learn flags around the world in 3 steps</h3>
            </div>
            <div className="center">
                <List />
            </div>    
            </div>
        </div>
    );
  }
}

function StepOneBlock(props) {
  return (
            <div>
                <div className="steps">Step 1</div> 
                <div className="steps-instruction">Select a continent.</div>
                <div className="dropdownContainer">
                <input type="text" onClick={() => props.onClick()} onChange={props.onChange} placeholder="Search..." />
                    <ul className="continentsSelect">
                        {  
                         props.showContinents ? props.itemList : null
                        }
                    </ul>
                </div>
                { props.showCountries ?
                <div className="selectedCountryIndicator">
                    <div className="steps-instruction">You selected</div>
                    <div className="countryIndicator">{props.selectedContinent}</div>
                </div>    
                    : null
                }    
            </div>
  );
}

function StepTwoBlock(props) {
  return (
            <div>
                <div className="steps">Step 2</div> 
                <div className="steps-instruction">Now, select a country.</div>
                <div className="dropdownContainer">
                { props.showCountries ? <input type="text" onClick={() => props.onClick()} onChange={props.onChange} placeholder="Search..." /> : null }
                    <ul>
                        {  
                         props.showCountriesList ? props.itemList : null
                        }
                    </ul>
                </div>
            </div>
  );
}

function StepThreeBlock(props) {
  return (
            <div>
                <div className="steps">Selected Flags:</div> 
                <div className="dropdownContainer" >
                    <ul id="menu">
                        {  
                         props.itemList
                        }
                    </ul>
                </div>
                <button className="clearFlagsButton" onClick={() => props.onClick()}>Clear flags</button>
            </div>
  );
}

class List extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            filteredContinents: [],
            filteredCountries: [],
            filteredFlagList: [],
            flagItem: [],
            showContinents: false,
            showCountries: false,
            showCountriesList: false,
            showFlags: false,
            continentsList: [],
            continentsData: [],
            countriesData: [],
            countriesHistory: [],
            selectedContinent: ''
        };
    }
    
    componentWillMount() {

     axios.get('../continents.json') // JSON File Path
       .then( response => {

       const continents = [];
       response.data.map(item => ( continents.push(item.continent)  ));  

        this.setState({
            continentsList: continents,
            continentsData: response.data,
            filteredContinents: continents
       });

     })
     .catch(function (error) {
        console.log(error);
     });

    }
    
    //filter the countries
    filterCountries(e) {
            // Variable to hold the original version of the list
        let currentList = [];
            // Variable to hold the filtered list before putting into state
        let newList = [];

            // If the search bar isn't empty
        if (e.target.value !== "") {
            // Assign the original list to currentList
            //currentList = this.props.items;
            currentList = this.state.countriesData;

                // Use .filter() to determine which items should be displayed
                // based on the search terms
            newList = currentList.filter(item => {
                      // change current item to lowercase
                const lc = item.toLowerCase();
                        // change search term to lowercase
                const filter = e.target.value.toLowerCase();
                        // check to see if the current list item includes the search term
                        // If it does, it will be added to newList. Using lowercase eliminates
                        // issues with capitalization in search terms and search content
                return lc.includes(filter);
            });
        } else {
            // If the search bar is empty, set newList to original task list
           //newList = this.props.items;
           newList = this.state.countriesData;

        }
            // Set the filtered state based on what our rules added to newList
        this.setState({
            filteredCountries: newList
        });
    }
    
    //filter the continents
    filterContinents(e) {
            // Variable to hold the original version of the list
        let currentList = [];
            // Variable to hold the filtered list before putting into state
        let newList = [];

            // If the search bar isn't empty
        if (e.target.value !== "") {
                // Assign the original list to currentList
            //currentList = this.props.items;
            currentList = this.state.continentsList;

            // Use .filter() to determine which items should be displayed
            // based on the search terms
            newList = currentList.filter(item => {
                      // change current item to lowercase
                const lc = item.toLowerCase();
                        // change search term to lowercase
                const filter = e.target.value.toLowerCase();
                        // check to see if the current list item includes the search term
                        // If it does, it will be added to newList. Using lowercase eliminates
                        // issues with capitalization in search terms and search content
                return lc.includes(filter);
            });
        } else {
            // If the search bar is empty, set newList to original task list
           //newList = this.props.items;
           newList = this.state.continentsList;
        }
            // Set the filtered state based on what our rules added to newList
        this.setState({
            filteredContinents: newList
        });
    }
    
    //display the comtinents section
    showContinents(){
        this.clearFlags();
        this.setState({ 
            //showContinents: true,
            showContinents: !this.state.showContinents,
            showCountriesList: false //hide the countries list when the continent is selected
        });
    }
     
    //display the countrries section 
    showCountriesList(){
        this.setState({ 
            showCountriesList: !this.state.showCountriesList, //toggle the countries drop down
            showFlags: false,  //clear the flag entities
            filteredFlagList: [],
            flagItem: []
        });

    }
    
    //build the countriesList based on the selected continent
    populateCountries(val){

          const countriesList = [];

          //find and return the matched continent
          const continents = this.state.continentsData.find((item) => item.continent === val);

          //select the countries list for the continent
          continents.countries.map(countries => (
                            //console.log(countries.name)
                            countriesList.push(countries.name) )); 

          this.setState({ 
              countriesData: countriesList,
              filteredCountries: countriesList,
              countriesHistory: continents.countries, //history of countries array with name and flag data
              showCountries: true,
              showContinents: false,
              selectedContinent: val
          });
    }
    
    //dynamically add or remove items from the flag lists based on the selected country
    showFlags(e){

        //fetch the selected country from the countriesHistory
        const selectedCountry = this.state.countriesHistory.find((item) => item.name === e.target.value);

        if(e.target.checked){  //only push the countries flag if checkbox is checked
          this.state.flagItem.push(selectedCountry.flag);
        }
        else{ //remove flag from the flag list if the checkbox has been unchecked
              const index = this.state.flagItem.indexOf(selectedCountry.flag);
              if (index > -1) {
                this.state.flagItem.splice(index, 1);
              }  
        }

        const flagItem = this.state.flagItem.slice();

        this.setState({ 
            showFlags: true,
            filteredFlagList: flagItem
        });
    }
  
    //call to clear the flagList and hide the flags section
    clearFlags(){
        this.setState({ 
            showFlags: false,
            showCountriesList: false,  //hide the countries list when clearing flags
            filteredFlagList: [],
            flagItem: []
        });
    }
    
    render() {
             
        const flagItems = this.state.filteredFlagList.slice();


        const continentsList = this.state.filteredContinents.map(item => (
                             <li onClick={() => this.populateCountries(item)} key={item}>
                                 {item}
                             </li>));

        const countriesList = this.state.filteredCountries.map(item => (
                             <li key={item}>
                                 <label><input type="checkbox" value={item} onClick={(e) => this.showFlags(e)} /><span>{item}</span></label>
                             </li>));                     

        const flagList = flagItems.map((item) => (
                             <li className="countryFlags" key={item}>
                                 <button>{item}</button>
                             </li>)); 
                    
        return (
         
            <div className="blockRow">        
                <div className="stepBlock">
                <StepOneBlock 
                    showContinents={this.state.showContinents}
                    showCountries={this.state.showCountries}
                    onClick={() => this.showContinents()}
                    onChange={(e) => this.filterContinents(e)}
                    itemList ={continentsList}
                    selectedContinent ={this.state.selectedContinent}
                />
            </div>
            
            <div className="stepBlock">
                {
                this.state.showCountries ? <StepTwoBlock 
                    showCountries={this.state.showCountries}
                    showCountriesList={this.state.showCountriesList}
                    onClick={() => this.showCountriesList()}
                    onChange={(e) => this.filterCountries(e)}
                    itemList ={countriesList}
                /> : null
                }
            </div>
            
            <div className="stepBlock">
                {
                this.state.showFlags ? <StepThreeBlock 
                    showFlags={this.state.showFlags}
                    onClick={() => this.clearFlags()}
                    itemList ={flagList}
                /> : null
                }
            </div>
        </div>    
                
        );
    }
}

ReactDOM.render(<App />, document.getElementById("root"));
